import { Request, Response } from 'express';
import prisma from '../config/prisma';
import { evaluateCandidateAgainstRequirements, CandidateEvaluationPayload } from '../services/evaluationService';
import { CandidateRecord, findCandidateRecord, getAllCandidateRecords, mapDbCandidateToRecord } from './candidateController';
import { AuthRequest } from '../middleware/authMiddleware';

/**
 * Standard requirement helper for fallback jobs or unseeded requisitions
 */
export function getStandardRequirementsForPosition(positionTitle: string, clientName?: string) {
  const titleLower = (positionTitle || '').toLowerCase();

  if (titleLower.includes('frontend') || titleLower.includes('react') || titleLower.includes('ui') || titleLower.includes('web')) {
    return [
      { id: 'req-fe-1', requirement: '3+ years experience with React, TypeScript, and modern state management', category: 'Experience', is_mandatory: true, weight: 2.0 },
      { id: 'req-fe-2', requirement: 'Proficiency with Next.js, responsive layouts, and Tailwind CSS', category: 'Technical Skill', is_mandatory: true, weight: 1.5 },
      { id: 'req-fe-3', requirement: 'Demonstrated experience integrating RESTful APIs and asynchronous data flows', category: 'Technical Skill', is_mandatory: true, weight: 1.5 },
      { id: 'req-fe-4', requirement: 'Hands-on experience with unit testing frameworks (Jest, React Testing Library)', category: 'Tool', is_mandatory: false, weight: 1.0 },
      { id: 'req-fe-5', requirement: 'Bachelor degree in Computer Science, Engineering, or equivalent practical experience', category: 'Education', is_mandatory: false, weight: 1.0 }
    ];
  }

  if (titleLower.includes('backend') || titleLower.includes('node') || titleLower.includes('python') || titleLower.includes('java') || titleLower.includes('golang')) {
    return [
      { id: 'req-be-1', requirement: '3+ years hands-on backend development and API architecture experience', category: 'Experience', is_mandatory: true, weight: 2.0 },
      { id: 'req-be-2', requirement: 'Strong proficiency in backend services, relational databases, and SQL', category: 'Technical Skill', is_mandatory: true, weight: 1.5 },
      { id: 'req-be-3', requirement: 'Experience designing secure microservices and performant data pipelines', category: 'Technical Skill', is_mandatory: true, weight: 1.5 },
      { id: 'req-be-4', requirement: 'Familiarity with containerization (Docker) and CI/CD deployment pipelines', category: 'Tool', is_mandatory: false, weight: 1.0 },
      { id: 'req-be-5', requirement: 'Degree in Computer Science, Information Technology, or equivalent', category: 'Education', is_mandatory: false, weight: 1.0 }
    ];
  }

  if (titleLower.includes('sap') || titleLower.includes('erp') || titleLower.includes('fico') || titleLower.includes('s/4hana')) {
    return [
      { id: 'req-sap-1', requirement: '5+ years experience in SAP CO / FICO module configuration and implementation', category: 'Experience', is_mandatory: true, weight: 2.0 },
      { id: 'req-sap-2', requirement: 'Deep expertise in Product Costing (CO-PC) and Material Ledger in S/4HANA', category: 'Technical Skill', is_mandatory: true, weight: 1.8 },
      { id: 'req-sap-3', requirement: 'Hands-on participation in at least 2 full end-to-end SAP lifecycle implementations', category: 'Experience', is_mandatory: true, weight: 1.5 },
      { id: 'req-sap-4', requirement: 'SAP Certified Application Associate - Financial Accounting or Management Accounting', category: 'Certification', is_mandatory: false, weight: 1.0 },
      { id: 'req-sap-5', requirement: 'Bachelor or Master degree in Finance, Accounting, Business, or Computer Science', category: 'Education', is_mandatory: false, weight: 1.0 }
    ];
  }

  // General Software Engineering / Tech Role Fallback
  return [
    { id: 'req-gen-1', requirement: '2+ years professional industry experience in software development or technical domain', category: 'Experience', is_mandatory: true, weight: 2.0 },
    { id: 'req-gen-2', requirement: 'Demonstrated proficiency in core required technologies and tools', category: 'Technical Skill', is_mandatory: true, weight: 1.5 },
    { id: 'req-gen-3', requirement: 'Proven experience collaborating on production systems and business workflows', category: 'Experience', is_mandatory: true, weight: 1.5 },
    { id: 'req-gen-4', requirement: 'Strong problem-solving skills, debugging ability, and technical documentation', category: 'Soft Skill', is_mandatory: false, weight: 1.0 },
    { id: 'req-gen-5', requirement: 'Higher education degree or equivalent relevant professional background', category: 'Education', is_mandatory: false, weight: 1.0 }
  ];
}

/**
 * Helper to fetch job record and confirmed requirements with organization validation
 */
async function getJobAndRequirements(jobId: string, fallbackPosition?: string, fallbackClient?: string) {
  let jobData: any = null;
  let requirements: any[] = [];

  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(jobId);
  if (isUuid) {
    try {
      const dbJob = await prisma.job.findUnique({
        where: { id: jobId },
        include: { requirements: true }
      });

      if (dbJob) {
        jobData = {
          id: dbJob.id,
          position: dbJob.position,
          title: dbJob.position,
          client: dbJob.client,
          company: dbJob.client,
          jd_text: dbJob.jd_text || undefined,
          created_by: dbJob.created_by,
        };
        if (dbJob.requirements && dbJob.requirements.length > 0) {
          requirements = dbJob.requirements;
        }
      }
    } catch (e) {
      console.warn('[Evaluation Controller] Job DB fetch error:', e);
    }
  }

  if (!jobData) {
    jobData = {
      id: jobId,
      position: fallbackPosition || 'Software Engineer',
      title: fallbackPosition || 'Software Engineer',
      client: fallbackClient || 'Client Organization',
      company: fallbackClient || 'Client Organization',
    };
  }

  if (requirements.length === 0) {
    requirements = getStandardRequirementsForPosition(jobData.position, jobData.client);
  }

  return { jobData, requirements };
}

/**
/**
 * Get detailed evaluation for a single candidate against a job (or by evaluation ID)
 * GET /api/evaluations/:id
 * GET /api/jobs/:jobId/candidates/:candidateId/evaluation
 */
export const getCandidateEvaluation = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = req.user;
    if (!user || !user.userId) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    const orgId = user.organizationId || 'org-tasknera';
    const idParam = String(req.params.candidateId || req.params.id || req.query.candidateId || '');
    const jobIdParam = String(req.params.jobId || req.query.jobId || '');

    if (!idParam) {
      res.status(400).json({ error: 'Evaluation or Candidate ID is required' });
      return;
    }

    // 1. Try to find evaluation in prisma.evaluation table
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(idParam);

    let evalRecord: any = null;
    if (isUuid) {
      evalRecord = await prisma.evaluation.findUnique({
        where: { id: idParam },
        include: { candidate: true, job: true, creator: true }
      });
    }

    if (!evalRecord) {
      const candWhere: any = { candidateId: idParam };
      if (jobIdParam) candWhere.jobId = jobIdParam;
      evalRecord = await prisma.evaluation.findFirst({
        where: candWhere,
        include: { candidate: true, job: true, creator: true },
        orderBy: { createdAt: 'desc' }
      });
    }

    if (evalRecord) {
      // Safe audit debug log
      console.log(`[Evaluation Access] userId=${user.userId} organizationId=${orgId} role=${user.role || 'MEMBER'} evalId=${evalRecord.id} evalOwner=${evalRecord.createdByUserId}`);

      // Security Check 1: Cross-Organization Isolation
      if (evalRecord.organizationId && evalRecord.organizationId !== orgId) {
        res.status(403).json({ error: 'Forbidden: Access restricted to organization members.' });
        return;
      }

      // Security Check 2: Non-Admin Ownership
      if (user.role !== 'ADMIN' && evalRecord.createdByUserId !== user.userId && evalRecord.assignedToUserId !== user.userId) {
        res.status(403).json({ error: 'Forbidden: Access restricted to evaluation owner.' });
        return;
      }

      const audit = (evalRecord.auditData as any) || {};

      res.status(200).json({
        success: true,
        evaluationId: evalRecord.id,
        candidateId: evalRecord.candidateId,
        jobId: evalRecord.jobId,
        overallScore: evalRecord.score,
        matchLevel: evalRecord.matchLevel,
        mandatoryRequirementFailed: evalRecord.mandatoryFailed,
        decision: evalRecord.decision,
        evaluation: {
          ...audit,
          evaluationId: evalRecord.id,
          candidateId: evalRecord.candidateId,
          candidateName: evalRecord.candidate?.name || audit.candidateName || 'Candidate',
          jobId: evalRecord.jobId,
          jobTitle: evalRecord.job?.position || audit.jobTitle || 'Job Position',
          jobCompany: evalRecord.job?.client || audit.jobCompany || 'Client Organization',
          overallScore: evalRecord.score,
          matchLevel: evalRecord.matchLevel,
          mandatoryRequirementFailed: evalRecord.mandatoryFailed,
          recommendation: evalRecord.decision
        },
        pillarScores: audit.pillarScores,
        pillars: audit.pillarScores,
        requirements: audit.requirements,
        requirementResults: audit.requirements,
        strengths: audit.strengths,
        gaps: audit.gaps,
        warnings: audit.warnings
      });
      return;
    }

    // 2. Fallback: Candidate + Job validation for on-the-fly evaluation within authorized scope
    const candidateData = await findCandidateRecord(idParam, jobIdParam || undefined);
    if (!candidateData) {
      res.status(404).json({ error: `Candidate with ID "${idParam}" not found.` });
      return;
    }

    const targetJobId = jobIdParam || candidateData.jobId;
    if (!targetJobId) {
      res.status(404).json({ error: 'Job ID is required for evaluation.' });
      return;
    }

    const { jobData, requirements } = await getJobAndRequirements(
      targetJobId,
      candidateData.currentTitle || undefined,
      candidateData.currentCompany || undefined
    );

    // If job belongs to someone else in non-admin mode
    if (user.role !== 'ADMIN' && jobData.created_by && jobData.created_by !== user.userId) {
      res.status(403).json({ error: 'Forbidden: Access restricted to job owner.' });
      return;
    }

    const evaluation = evaluateCandidateAgainstRequirements(candidateData, jobData, requirements);

    res.status(200).json({
      success: true,
      evaluation,
      evaluationId: evaluation.evaluationId,
      candidateId: evaluation.candidateId,
      jobId: evaluation.jobId,
      overallScore: evaluation.overallScore,
      matchLevel: evaluation.matchLevel,
      mandatoryRequirementFailed: evaluation.mandatoryRequirementFailed,
      mandatoryFailures: evaluation.mandatoryFailures,
      pillarScores: evaluation.pillarScores,
      pillars: evaluation.pillarScores,
      requirements: evaluation.requirements,
      requirementResults: evaluation.requirements,
      strengths: evaluation.strengths,
      gaps: evaluation.gaps,
      warnings: evaluation.warnings
    });
  } catch (error: any) {
    console.error('Error in getCandidateEvaluation:', error);
    res.status(500).json({ error: error.message || 'Failed to retrieve candidate evaluation' });
  }
};

/**
 * Trigger fresh re-evaluation for a candidate against a job
 * POST /api/jobs/:jobId/candidates/:candidateId/evaluate
 */
export const evaluateCandidateController = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const candidateId = String(req.params.candidateId || req.params.id || '');
    const jobId = String(req.params.jobId || '');

    if (!candidateId || !jobId) {
      res.status(400).json({ error: 'Both Job ID and Candidate ID are required for re-evaluation.' });
      return;
    }

    const candidateData = await findCandidateRecord(candidateId, jobId);
    if (!candidateData) {
      res.status(404).json({ error: `Candidate with ID "${candidateId}" not found.` });
      return;
    }

    // Fetch latest job requirements
    const { jobData, requirements } = await getJobAndRequirements(
      jobId,
      candidateData.currentTitle || undefined,
      candidateData.currentCompany || undefined
    );

    // Run deterministic evaluation
    const evaluation = evaluateCandidateAgainstRequirements(candidateData, jobData, requirements);

    // Update application record match score if application exists in DB
    try {
      await prisma.candidateApplication.upsert({
        where: {
          job_id_candidate_id: {
            job_id: jobId,
            candidate_id: candidateId
          }
        },
        update: {
          match_score: evaluation.overallScore
        },
        create: {
          job_id: jobId,
          candidate_id: candidateId,
          match_score: evaluation.overallScore,
          stage: 'SOURCED'
        }
      });
    } catch {
      // Memory fallback if DB unavailable
    }

    res.status(200).json({
      success: true,
      message: 'Candidate re-evaluated successfully',
      evaluation,
      evaluationId: evaluation.evaluationId,
      candidateId: evaluation.candidateId,
      jobId: evaluation.jobId,
      overallScore: evaluation.overallScore,
      matchLevel: evaluation.matchLevel,
      mandatoryRequirementFailed: evaluation.mandatoryRequirementFailed,
      mandatoryFailures: evaluation.mandatoryFailures,
      pillarScores: evaluation.pillarScores,
      pillars: evaluation.pillarScores,
      requirements: evaluation.requirements,
      requirementResults: evaluation.requirements,
      strengths: evaluation.strengths,
      gaps: evaluation.gaps,
      warnings: evaluation.warnings
    });
  } catch (error: any) {
    console.error('Error during candidate re-evaluation:', error);
    res.status(500).json({ error: error.message || 'Failed to re-evaluate candidate' });
  }
};

/**
 * Get all candidate evaluations across all jobs
 * GET /api/evaluations
 */
export const getAllEvaluations = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = req.user;
    if (!user || !user.userId) {
      res.status(401).json({ error: 'Authentication required to access evaluations' });
      return;
    }

    const orgId = user.organizationId || 'org-tasknera';

    // Safe debug logging (identifiers only, strictly no candidate personal data)
    console.log(`[Evaluation Access] userId=${user.userId} organizationId=${orgId} role=${user.role || 'MEMBER'}`);

    // Database-level authorization:
    // - Organization isolation: organizationId = user.organizationId
    // - Member level: createdByUserId = user.userId OR assignedToUserId = user.userId
    // - Admin level: see all within organization
    const whereClause: any = { organizationId: orgId };
    if (user.role !== 'ADMIN') {
      whereClause.OR = [
        { createdByUserId: user.userId },
        { assignedToUserId: user.userId }
      ];
    }

    const dbEvaluations = await prisma.evaluation.findMany({
      where: whereClause,
      include: {
        candidate: {
          select: {
            id: true,
            name: true,
            current_title: true,
            current_company: true,
            resume_file_url: true,
            location: true
          }
        },
        job: {
          select: {
            id: true,
            position: true,
            client: true,
            location: true,
            status: true
          }
        },
        creator: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const evaluationItems = dbEvaluations.map(ev => {
      const score = Math.round(ev.score);
      const audit = (ev.auditData as any) || {};

      const isInvalidComp = (s?: string | null) => !s || ['the role', 'role', 'the company', 'company', 'organization', 'position', 'the position', 'candidate profile', 'unknown', 'not specified', 'verified organization', 'enterprise client'].includes(s.trim().toLowerCase()) || s.length < 2;

      const comp = (ev.job?.client && !isInvalidComp(ev.job.client))
        ? ev.job.client
        : (audit.jobCompany && !isInvalidComp(audit.jobCompany))
        ? audit.jobCompany
        : 'Client Organization';

      const role = (ev.job?.position && !['candidate profile', 'candidate', 'professional role'].includes(ev.job.position.trim().toLowerCase()))
        ? ev.job.position
        : (ev.candidate?.current_title || audit.jobTitle || 'Software Engineer');

      return {
        id: ev.candidateId,
        evaluationId: ev.id,
        candidate: ev.candidate?.name || audit.candidateName || 'Candidate',
        candidateId: ev.candidateId,
        role,
        job: role,
        jobId: ev.jobId,
        company: comp,
        date: new Date(ev.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
        score,
        ats: Math.round(ev.atsScore ?? score),
        overallScore: score,
        matchLevel: ev.matchLevel || (score >= 80 ? 'STRONG MATCH' : 'GOOD MATCH'),
        mandatory: ev.mandatoryCompliance || 'N/A',
        mandatoryFailed: ev.mandatoryFailed,
        decision: ev.decision || 'REVIEW',
        by: ev.creator?.name ? `Evaluated by ${ev.creator.name}` : 'Deterministic ATS Engine (v2.0)'
      };
    });

    res.status(200).json({
      success: true,
      total: evaluationItems.length,
      evaluations: evaluationItems
    });
  } catch (error: any) {
    console.error('Error fetching all evaluations:', error);
    res.status(500).json({ error: 'Failed to retrieve candidate evaluations' });
  }
};

/**
 * In-memory / fast-lookup cache for JD-specific ATS Candidate Evaluations
 * Key format: `${candidateId}___${jobId}`
 */
export const EVALUATION_CACHE = new Map<string, CandidateEvaluationPayload>();

/**
 * Match a Candidate from Candidate Pool with a specific Job Description (Entry Point 2)
 * POST /api/candidates/:candidateId/match-with-job
 */
export const matchCandidateWithJobController = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const candidateId = String(req.params.candidateId || req.params.id || '');
    const { jobId, reevaluate } = req.body;

    if (!candidateId) {
      res.status(400).json({ status: 'ERROR', message: 'Candidate ID is required for matching.' });
      return;
    }
    if (!jobId) {
      res.status(400).json({ status: 'ERROR', message: 'Job ID is required to match with Candidate.' });
      return;
    }

    // 1. Validate Candidate Presence & Parsing Readiness
    const candidateData = await findCandidateRecord(candidateId, jobId);
    if (!candidateData) {
      res.status(404).json({
        status: 'NOT_FOUND',
        message: `Candidate with ID "${candidateId}" not found in database or candidate pool.`
      });
      return;
    }

    const isReady = candidateData.parsingStatus === 'PARSED' ||
                    (candidateData.rawText && candidateData.rawText.length > 20) ||
                    (candidateData.skills && candidateData.skills.length > 0);

    if (!isReady || candidateData.parsingStatus === 'FAILED') {
      res.status(400).json({
        status: 'NOT_READY',
        message: 'Candidate CV is not ready for evaluation.'
      });
      return;
    }

    // 2. Validate Job & Confirmed Requirements
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(jobId);
    let dbJob: any = null;
    if (isUuid) {
      dbJob = await prisma.job.findUnique({
        where: { id: jobId },
        include: { requirements: true }
      });
    }

    if (!dbJob && jobId !== 'jd-1') {
      res.status(404).json({
        status: 'NOT_FOUND',
        message: `Selected Job Description with ID "${jobId}" was not found.`
      });
      return;
    }

    const { jobData, requirements } = await getJobAndRequirements(
      jobId,
      candidateData.currentTitle || undefined,
      candidateData.currentCompany || undefined
    );

    const hasRequirements = requirements && requirements.length > 0;
    const isConfirmed = hasRequirements && (
      requirements.some((r: any) => r.recruiter_confirmed === true) ||
      requirements.length >= 2 ||
      !isUuid // fallback demo job
    );

    if (!hasRequirements || !isConfirmed) {
      res.status(400).json({
        status: 'NOT_READY',
        message: 'JD requirements must be confirmed before evaluation.'
      });
      return;
    }

    // 3. Check if Candidate has already been evaluated for this Job by THIS user
    const user = req.user;
    if (!user || !user.userId) {
      res.status(401).json({ error: 'Authentication required to evaluate candidate.' });
      return;
    }

    const createdByUserId = user.userId;
    const organizationId = user.organizationId || 'org-tasknera';

    const existingEvalRecord = await prisma.evaluation.findFirst({
      where: {
        candidateId,
        jobId,
        createdByUserId
      }
    });

    if (existingEvalRecord && !reevaluate) {
      res.status(200).json({
        success: true,
        evaluationId: existingEvalRecord.id,
        candidateId: candidateId,
        jobId: jobId,
        status: 'COMPLETED',
        alreadyEvaluated: true,
        overallScore: existingEvalRecord.score,
        matchLevel: existingEvalRecord.matchLevel,
        mandatoryRequirementFailed: existingEvalRecord.mandatoryFailed,
        decision: existingEvalRecord.decision,
        evaluation: (existingEvalRecord.auditData as any) || {}
      });
      return;
    }

    // 4. Run Existing Requirement Matching & Deterministic Scoring Engine (DO NOT REPARSE)
    const evaluation = evaluateCandidateAgainstRequirements(candidateData, jobData, requirements);

    const finalScore = evaluation.overallScore ?? evaluation.overallMatch ?? 0;
    const complianceStr = evaluation.mandatoryCompliance
      ? `${evaluation.mandatoryCompliance.met}/${evaluation.mandatoryCompliance.total}`
      : 'N/A';
    const decision = evaluation.recommendation || (finalScore >= 80 ? 'SUBMIT' : (finalScore >= 60 ? 'REVIEW' : 'DO NOT SUBMIT'));

    // 5. Store / Upsert in PostgreSQL Evaluation Table (Enforcing Authenticated User Ownership)
    let savedEvalRecord;
    if (existingEvalRecord) {
      savedEvalRecord = await prisma.evaluation.update({
        where: { id: existingEvalRecord.id },
        data: {
          score: finalScore,
          atsScore: evaluation.atsScore ?? finalScore,
          matchLevel: evaluation.matchLevel,
          mandatoryCompliance: complianceStr,
          mandatoryFailed: Boolean(evaluation.mandatoryRequirementFailed),
          decision,
          auditData: evaluation as any,
          updatedAt: new Date()
        }
      });
    } else {
      savedEvalRecord = await prisma.evaluation.create({
        data: {
          candidateId,
          jobId,
          createdByUserId,
          organizationId,
          score: finalScore,
          atsScore: evaluation.atsScore ?? finalScore,
          matchLevel: evaluation.matchLevel,
          mandatoryCompliance: complianceStr,
          mandatoryFailed: Boolean(evaluation.mandatoryRequirementFailed),
          decision,
          status: 'COMPLETED',
          auditData: evaluation as any
        }
      });
    }

    // Also update fast cache
    const cacheKey = `${candidateId}___${jobId}`;
    EVALUATION_CACHE.set(cacheKey, evaluation);

    // 6. Record/Upsert Candidate + Job association in PostgreSQL without duplicating Candidate
    const isCandUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(candidateId);
    if (isUuid && isCandUuid) {
      const stage = finalScore >= 80 ? 'SHORTLISTED' : (finalScore >= 55 ? 'REVIEW' : 'REJECTED');
      await prisma.candidateApplication.upsert({
        where: {
          job_id_candidate_id: {
            job_id: jobId,
            candidate_id: candidateId
          }
        },
        update: {
          match_score: finalScore,
          stage,
          updated_at: new Date()
        },
        create: {
          job_id: jobId,
          candidate_id: candidateId,
          match_score: finalScore,
          stage,
          status: 'active'
        }
      }).catch(err => {
        console.warn('[Candidate Application Upsert Notice]:', err);
      });
    }

    // 7. Successful Response
    res.status(200).json({
      success: true,
      evaluationId: savedEvalRecord.id,
      candidateId: candidateId,
      jobId: jobId,
      status: 'COMPLETED',
      alreadyEvaluated: false,
      overallScore: savedEvalRecord.score,
      matchLevel: savedEvalRecord.matchLevel,
      mandatoryRequirementFailed: savedEvalRecord.mandatoryFailed,
      decision: savedEvalRecord.decision,
      evaluation: evaluation
    });
  } catch (error: any) {
    console.error('Error matching candidate with job:', error);
    res.status(500).json({ error: error.message || 'Failed to match candidate with job description' });
  }
};

/**
 * Get all job-specific evaluations for a single candidate across their application history
 * GET /api/candidates/:candidateId/evaluations
 */
export const getCandidateEvaluationHistoryController = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const candidateId = String(req.params.candidateId || req.params.id || '');
    if (!candidateId) {
      res.status(400).json({ error: 'Candidate ID is required' });
      return;
    }

    const candidate = await findCandidateRecord(candidateId);
    if (!candidate) {
      res.status(404).json({ error: `Candidate with ID "${candidateId}" not found.` });
      return;
    }

    const isCandUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(candidateId);
    let applications: any[] = [];
    if (isCandUuid) {
      const appWhere: any = { candidate_id: candidateId };
      if (req.user && req.user.role !== 'ADMIN') {
        appWhere.job = { created_by: req.user.userId };
      }
      applications = await prisma.candidateApplication.findMany({
        where: appWhere,
        include: {
          job: {
            select: {
              id: true,
              position: true,
              client: true,
              location: true,
              work_mode: true,
              status: true,
              created_by: true
            }
          }
        },
        orderBy: { updated_at: 'desc' }
      }).catch(() => []);
    }

    const historyItems: any[] = [];
    const seenJobIds = new Set<string>();

    for (const app of applications) {
      if (app.job) {
        seenJobIds.add(app.job_id);
        const cacheKey = `${candidateId}___${app.job_id}`;
        const cached = EVALUATION_CACHE.get(cacheKey);

        historyItems.push({
          jobId: app.job.id,
          jobTitle: app.job.position,
          position: app.job.position,
          client: app.job.client,
          company: app.job.client,
          location: app.job.location || 'Remote',
          score: app.match_score !== null ? Math.round(app.match_score) : (cached?.overallScore || null),
          matchLevel: cached?.matchLevel || (app.match_score && app.match_score >= 80 ? 'STRONG MATCH' : 'GOOD MATCH'),
          status: app.stage || 'SOURCED',
          stage: app.stage || 'SOURCED',
          date: app.updated_at ? new Date(app.updated_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : 'Recent',
          evaluationId: cached?.evaluationId || `eval-${app.id}`,
          alreadyEvaluated: Boolean(cached || app.match_score !== null)
        });
      }
    }

    // Include any in-memory cached evaluations for this candidate
    for (const [key, evalData] of EVALUATION_CACHE.entries()) {
      if (key.startsWith(`${candidateId}___`)) {
        const jId = key.split('___')[1];
        if (!seenJobIds.has(jId)) {
          seenJobIds.add(jId);
          const evalScore = evalData.overallScore ?? evalData.overallMatch ?? 0;
          historyItems.push({
            jobId: jId,
            jobTitle: evalData.jobTitle || 'Job Position',
            position: evalData.jobTitle || 'Job Position',
            client: evalData.jobClient || 'Enterprise Client',
            company: evalData.jobClient || 'Enterprise Client',
            location: 'Remote',
            score: evalScore,
            matchLevel: evalData.matchLevel || (evalScore >= 80 ? 'STRONG MATCH' : 'GOOD MATCH'),
            status: evalScore >= 80 ? 'SHORTLISTED' : 'REVIEW',
            stage: evalScore >= 80 ? 'SHORTLISTED' : 'REVIEW',
            date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
            evaluationId: evalData.evaluationId,
            alreadyEvaluated: true
          });
        }
      }
    }

    res.status(200).json({
      success: true,
      candidateId,
      candidateName: candidate.name,
      total: historyItems.length,
      evaluations: historyItems
    });
  } catch (error: any) {
    console.error('Error fetching candidate evaluation history:', error);
    res.status(500).json({ error: 'Failed to retrieve candidate evaluation history' });
  }
};

/**
 * Get all authorized jobs in the organization available for matching against this candidate
 * GET /api/candidates/:candidateId/available-jobs
 */
export const getAvailableJobsForCandidateController = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const candidateId = String(req.params.candidateId || req.params.id || '');
    if (!candidateId) {
      res.status(400).json({ error: 'Candidate ID is required' });
      return;
    }

    const candidate = await findCandidateRecord(candidateId);
    if (!candidate) {
      res.status(404).json({ error: `Candidate with ID "${candidateId}" not found.` });
      return;
    }

    const isCandUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(candidateId);

    const jobWhere: any = { status: { not: 'archived' } };
    if (req.user && req.user.role !== 'ADMIN') {
      jobWhere.created_by = req.user.userId;
    }

    // Fetch active jobs (filtered by creator for members, all for admin)
    const dbJobs = await prisma.job.findMany({
      where: jobWhere,
      include: {
        requirements: true,
        applications: isCandUuid ? {
          where: { candidate_id: candidateId }
        } : false
      },
      orderBy: { created_at: 'desc' }
    });

    // Query evaluations created by this user for this candidate across these jobs
    const userEvals = await prisma.evaluation.findMany({
      where: {
        candidateId,
        jobId: { in: dbJobs.map(j => j.id) },
        createdByUserId: req.user?.userId || ''
      }
    });
    const userEvalMap = new Map(userEvals.map(ev => [ev.jobId, ev]));

    const jobs = dbJobs.map(j => {
      const app = (j.applications as any)?.[0];
      const userEval = userEvalMap.get(j.id);
      const isEvaluated = Boolean(userEval);
      const score = userEval ? Math.round(userEval.score) : (app?.match_score !== null && app?.match_score !== undefined ? Math.round(app.match_score) : null);

      return {
        id: j.id,
        position: j.position,
        jobTitle: j.position,
        client: j.client,
        company: j.client,
        location: j.location || 'Remote',
        workMode: j.work_mode || 'Full-time',
        status: j.status,
        salary: j.salary,
        requirementsCount: j.requirements ? j.requirements.length : 0,
        requirementsConfirmed: j.requirements ? (j.requirements.some(r => r.recruiter_confirmed) || j.requirements.length >= 2) : false,
        isAlreadyMatched: Boolean(app),
        isAlreadyEvaluated: isEvaluated,
        matchScore: score,
        stage: userEval ? (score && score >= 80 ? 'SHORTLISTED' : 'REVIEW') : (app?.stage || 'SOURCED'),
        createdAt: j.created_at
      };
    });

    res.status(200).json({
      success: true,
      candidateId,
      candidateName: candidate.name,
      total: jobs.length,
      jobs
    });
  } catch (error: any) {
    console.error('Error getting available jobs for candidate:', error);
    res.status(500).json({ error: 'Failed to retrieve available jobs for candidate' });
  }
};

/**
 * Update evaluation decision (SUBMIT, REVIEW, DO NOT SUBMIT)
 * POST /api/evaluations/:id/decision
 * PATCH /api/evaluations/:id/decision
 */
export const updateEvaluationDecisionController = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = req.user;
    if (!user || !user.userId) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    const id = String(req.params.id || '');
    const rawDecision = String(req.body.decision || '').trim().toUpperCase();

    if (!rawDecision || !['SUBMIT', 'REVIEW', 'DO NOT SUBMIT', 'REJECT'].includes(rawDecision)) {
      res.status(400).json({ error: 'Invalid decision. Must be SUBMIT, REVIEW, or DO NOT SUBMIT' });
      return;
    }

    const standardDecision = rawDecision === 'REJECT' ? 'DO NOT SUBMIT' : rawDecision;

    const evaluation = await prisma.evaluation.findUnique({
      where: { id }
    });

    if (!evaluation) {
      res.status(404).json({ error: 'Evaluation not found' });
      return;
    }

    const orgId = user.organizationId || 'org-tasknera';
    if (evaluation.organizationId && evaluation.organizationId !== orgId) {
      res.status(403).json({ error: 'Forbidden: Access restricted to organization members.' });
      return;
    }

    if (user.role !== 'ADMIN' && evaluation.createdByUserId !== user.userId && evaluation.assignedToUserId !== user.userId) {
      res.status(403).json({ error: 'Forbidden: Only evaluation owner or admin can update decision.' });
      return;
    }

    const updated = await prisma.evaluation.update({
      where: { id },
      data: {
        decision: standardDecision,
        updatedAt: new Date()
      }
    });

    res.status(200).json({
      success: true,
      message: `Evaluation decision updated to ${standardDecision}`,
      evaluation: updated
    });
  } catch (error: any) {
    console.error('Error updating evaluation decision:', error);
    res.status(500).json({ error: error.message || 'Failed to update evaluation decision' });
  }
};

/**
 * Delete evaluation
 * DELETE /api/evaluations/:id
 */
export const deleteEvaluationController = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = req.user;
    if (!user || !user.userId) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    const id = String(req.params.id || '');

    const evaluation = await prisma.evaluation.findUnique({
      where: { id }
    });

    if (!evaluation) {
      res.status(404).json({ error: 'Evaluation not found' });
      return;
    }

    const orgId = user.organizationId || 'org-tasknera';
    if (evaluation.organizationId && evaluation.organizationId !== orgId) {
      res.status(403).json({ error: 'Forbidden: Access restricted to organization members.' });
      return;
    }

    if (user.role !== 'ADMIN' && evaluation.createdByUserId !== user.userId) {
      res.status(403).json({ error: 'Forbidden: Only evaluation owner or admin can delete evaluation.' });
      return;
    }

    await prisma.evaluation.delete({
      where: { id }
    });

    res.status(200).json({
      success: true,
      message: 'Evaluation deleted successfully'
    });
  } catch (error: any) {
    console.error('Error deleting evaluation:', error);
    res.status(500).json({ error: error.message || 'Failed to delete evaluation' });
  }
};

/**
 * Connect Candidate to Job (create/reuse CandidateJob)
 * POST /api/candidates/:candidateId/jobs
 */
export const attachCandidateToJobController = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const candidateId = String(req.params.candidateId || req.params.id || '');
    const jobId = String(req.body.jobId || req.body.job_id || '');

    if (!candidateId || !jobId) {
      res.status(400).json({ error: 'candidateId and jobId are required' });
      return;
    }

    const candidate = await findCandidateRecord(candidateId);
    if (!candidate) {
      res.status(404).json({ error: `Candidate with ID "${candidateId}" not found.` });
      return;
    }

    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(jobId);
    const isCandUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(candidateId);

    let candidateJobId = `cj-${candidateId}-${jobId}`;

    if (isUuid && isCandUuid) {
      const app = await prisma.candidateApplication.upsert({
        where: {
          job_id_candidate_id: {
            job_id: jobId,
            candidate_id: candidateId
          }
        },
        update: {
          updated_at: new Date()
        },
        create: {
          job_id: jobId,
          candidate_id: candidateId,
          stage: 'SOURCED',
          status: 'active'
        }
      });
      candidateJobId = app.id;
    }

    res.status(200).json({
      success: true,
      candidateId,
      jobId,
      candidateJobId,
      status: 'READY'
    });
  } catch (error: any) {
    console.error('Error attaching candidate to job:', error);
    res.status(500).json({ error: 'Failed to attach candidate to job' });
  }
};

/**
 * Start/Execute Evaluation for a Candidate against a specific Job
 * POST /api/candidates/:candidateId/jobs/:jobId/evaluate
 */
export const evaluateCandidateJobController = async (req: AuthRequest, res: Response): Promise<void> => {
  req.body.jobId = req.params.jobId || req.body.jobId;
  return matchCandidateWithJobController(req, res);
};

